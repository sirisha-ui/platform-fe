import React from 'react';
import { connect } from 'react-redux';
// import sidebar from "../sidebar";
import { bindActionCreators } from "redux";

// import betHistoryTable from './betHistoryTable';
class LoginHistory extends React.Component{

    constructor(props){
        
        super(props);
        this.state = {
            id: '',
        betType: '',
        betId: '',
        sport: '',
        brand: '',
        description: '',
        eventName: '',
        stake: '',
        totalStake: '',
        win: '',
        customer: '',
        placedOn: '',
        settledOn: '',
        rejectionCode: '',
        walletID: '',
        currency: '',
        customerId: '',
        rejected: '',
        voided: '',
        subcategory: '',
        placedBefore: '',
        placedAfter: '',
        resulted: '',
        market: '',
            data: [],
        }

        this.onChangeBrand = this.onChangeBrand.bind(this);
        this.onChangeCurrency = this.onChangeCurrency.bind(this);
         
        // this.onSubmit = this.onSubmit.bind(this);
            
            
        }



    resetButton() {
        this.setState({
        id: '',
        betType: '',
        betId: '',
        sport: '',
        brand: '',
        description: '',
        eventName: '',
        stake: '',
        totalStake: '',
        win: '',
        customer: '',
        placedOn: '',
        settledOn: '',
        rejectionCode: '',
        walletID: '',
        currency: '',
        customerId: '',
        rejected: '',
        voided: '',
        subcategory: '',
        placedBefore: '',
        placedAfter: '',
        resulted: '',
        market: '',
        data: [],})
        this.setState({data:[]})
       }

     

    onChangeCurrency(e) {
        this.setState({ currency: e.target.value })
    }
   
  onChangeBrand(e){
     this.setState({brand: e.target.value})
  }

  

//   onChangeItemperpage(e){
//      this.setState({itemsperpage: e.target.value})
//      this.props.dispatch(setPaginationSecondValue(e.target.value))
//      this.props.dispatch(getPlayerSearchList(this.props.paginationFirstValue,e.target.value,this.state.data))
      
//   }

//     onSubmit(e) {
//         e.preventDefault()
//         // e.target.resetButton();
//         //this.props.dispatch(getPlayerSearchList)(this.props)
//         debugger
//         // if(this.state.username != '' || this.state.firstName != '' || this.state.lastName != '' || this.state.email != '' || this.state.customerId != ''
//         // || this.state.ipAddress != '' || this.state.phoneNumber != '' || this.state.country != '' ||  this.state.datepicker != '' || this.state.referCode != '' ||
//         // this.state.cgr != '' || this.state.AccountSatus != ''){
//            this.setState({data:{ brand: this.state.brand,
//             betType: this.state.betType,
//             settled: this.state.settled,
//             sport: this.state.sport,
//               customerId: this.state.customerId,
//               currency: this.state.currency,
//               rejected: this.state.rejected,
//               voided: this.state.voided,
//               subcategory: this.state.subcategory,
//               placedBefore: this.state.placedBefore,
//               rejectionCode: this.state.rejectionCode,
//               betId: this.state.betId,
//               event: this.state.event,
//               placedAfter: this.state.placedAfter,
//               resulted: this.state.resulted,
//               market: this.state.market
//               }
//          })
// //var  playerserachdata =[];
// var playerserachdata=  { brand: this.state.brand,
//         betType: this.state.betType,
//         settled: this.state.settled,
//         sport: this.state.sport,
//         customerId: this.state.customerId,
//         currency: this.state.currency,
//         rejected: this.state.rejected,
//         voided: this.state.voided,
//         subcategory: this.state.subcategory,
//         placedBefore: this.state.placedBefore,
//         rejectionCode: this.state.rejectionCode,
//         betId: this.state.betId,
//         event: this.state.event,
//         placedAfter: this.state.placedAfter,
//         resulted: this.state.resulted,
//         market: this.state.market,

//         }
//         //this.props.dispatch(getPlayerSearchList(this.props.paginationFirstValue,this.props.paginationSecondValue,playerserachdata))
        
//         //}
//      }
    render(){
        return(<>
        <div className="CMS-tabContent" style ={{width: this.props.displayValue ? '100%':'80%', marginLeft: this.props.displayValue ?'0px':'295px'}}>
        {/* <div className="CMS-page-tabs">
                                <ul>

                                    {
                                   this.props.sidebarTabs.length > 0 && this.props.sidebarTabs.map((item,index)=> {return (
                                    <>   
                                    <li key={index} >
                                       
                                       <span to="#">{item.subtitle} 
                                          </span>
                                          <span className="close"><span className="material-icons md-18" data-icon="close" onClick={()=>this.navLinksClosedFunction(item)}></span> </span>
                                   
                                    </li>
                                    </>
                                    )})}
                                  
                                </ul>
                            </div>  */}
                            <div class="CMS-page-tabs">
                                <ul>
                                    <li class="active">
                                        <a href="CMS-betting">Login History<span class="close"
                                                onclick="window.location.href='dashboard.html'"><span
                                                    class="material-icons md-18" data-icon="close"></span></span></a>
                                    </li>

                                </ul>
                            </div>
                                     
                                        <div className="CMS-box CMS-box-content">
                                            <div className="row no-gutters">
                                                
                                            <div class="col-md-4 col-lg-3 col-xl-2">
                                                    <div class="CMS-formGroup">
                                                        <div class="CMS-formLabel">Id</div>
                                                        <div class="CMS-dropdown CMS-brands-dropdown CMS-formControl">
                                                            <div class="CMS-dropdown-btn">All Brands</div>
                                                            <div class="CMS-dropdown-menu CMS-form-group">

                                                            <select value={this.state.brand} onChange={this.onChangeBrand}>
                                                              <option>Select</option>
                                                                <option>Ken</option>
                                                                 <option>UG</option>
                                                                      <option>NG</option>
                                                                       <option>ZM</option>
                                                                        <option>UGX</option>
                                                                          <option>NGN</option>
                                                                          <option>TZ</option>
                                                                         </select>
                                                               
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                

                                                <div class="col-md-4 col-lg-3 col-xl-2">
                                                    <div class="CMS-formGroup">
                                                        <div class="CMS-formLabel">Date</div>
                                                        <div class="CMS-dropdown CMS-formControl">
                                                            <div class="CMS-select">
                                                                <select>
                                                                    <option>All Events</option>
                                                                    <option>Pre Match Only</option>
                                                                    <option>In-Play Only</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-lg-4 col-xl-3">
                                                                <div class="CMS-formGroup">
                                                                    <div class="CMS-formLabel">Action Type</div>
                                                                    <div class="CMS-dropdown CMS-formControl">
                                                                        <div class="CMS-select">
                                                                            <select>
                                                                                <option>Select</option>
                                                                                <option>Login</option>
                                                                                <option>Logout</option>
                                                                                <option>Account Status Change</option>

                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                <div class="col-md-4 col-lg-3 col-xl-2">
                                                    <div class="CMS-formGroup">
                                                        <div class="CMS-formLabel">Ip Address</div>
                                                        <div class="CMS-dropdown CMS-formControl">
                                                            <div class="CMS-select">
                                                                <select>
                                                                    <option>All Bet Factors</option>
                                                                    <option>Less Than 1</option>
                                                                    <option>Exactly 1</option>
                                                                    <option>Mor Than 1</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                
                                                
                                            </div>

                                           
                                            <div className="mt-20"></div>

                                          
                                         
                                         <div class="row">
                                                <div class="col-md-12 col-lg-12 col-xl-12">
                                                    <div class="CMS-btnContainer">
                                                        <button onclick="myFunction()"
                                                            class="CMS-btn CMS-btnSecondary active CMS-btnMedium"
                                                            type="button">Search</button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="CMS-filter-result" id="result">
                        <div className="CMS-pagination">
                           <div className="CMS-pagination-container">
                              <div className="CMS-pagination-list">
                                 <ul>
                                    <li><a href="#"><span className="material-icons" data-icon="first_page"></span></a></li>
                                    <li><a href="#"><span className="material-icons" data-icon="navigate_before"></span></a></li>
                                   
                                      
                                    <li><a className="active" href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <li><a href="#">3</a></li>
                                    
                                    <li><a href="#"><span className="material-icons" data-icon="navigate_next"></span></a></li>
                                    <li><a href="#"><span className="material-icons" data-icon="last_page"></span></a></li>
                                 </ul>
                              </div>
                              <div className="CMS-page-slection">
                                 <div className="CMS-number-of-files CMS-select">
                                    <select id="country" name="File" >
                                       <option value="25">25</option>
                                       <option value="50">50</option>
                                       <option value="100">100</option>
                                       <option value="200">200</option>
                                       <option value="500">500</option>
                                    </select>
                                 </div>
                                 <div className="CMS-file-type CMS-select">
                                    <select id="country" name="File">
                                       <option value="PDF">PDF</option>
                                       <option value="CSV">CSV</option>
                                       <option value="XLS">XLS</option>
                                    </select>
                                 </div>
                                 <div className="CMS-download-icon">
                                    <a href="#"><span className="material-icons" data-icon="file_download"></span></a>
                                 </div>
                              </div>
                              <div className="CMS-page-results">
                                 {/* Results {this.props.paginationFirstValue}-{this.props.paginationSecondValue} of {this.props.paginationSecondValue} 
                               */}
                               Results of 25
                              </div>
                           </div>
                        </div>
                     </div>
                                        </div>
                                    </div>

                    


                                    <div class="CMS-box CMS-table CMS-table-triped tableHeght" style ={{width: this.props.displayValue ? '100%':'79%', marginLeft: this.props.displayValue ?'0px':'295px'}}>
                                    
                                                <table>
                                                    <thead>
                                                        <tr>
                                                            <th>ID</th>
                                                            <th>Created</th>
                                                            <th>Destroyed</th>
                                                            <th>Client UID</th>
                                                            <th>Site Name</th>
                                                            <th>Country Code</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>17051</td>
                                                            <td>18/08/2021 13:47:36</td>
                                                            <td>28/08/2021 13:47:36</td>
                                                            <td></td>
                                                            <td>Betlion-ke Web</td>
                                                            <td>IE</td>
                                                        </tr>
                                                        <tr>
                                                            <td>16991</td>
                                                            <td>28/08/2021 13:47:36</td>
                                                            <td>29/08/2021 13:47:36</td>
                                                            <td></td>
                                                            <td>Betlion-ke Web</td>
                                                            <td>IE</td>
                                                        </tr>
                                                        <tr>
                                                            <td>16581</td>
                                                            <td>10/08/2021 13:47:36</td>
                                                            <td>15/08/2021 13:47:36</td>
                                                            <td></td>
                                                            <td>Betlion-ke Web</td>
                                                            <td>IE</td>
                                                        </tr>
                                                        <tr>
                                                            <td>16482</td>
                                                            <td>11/08/2021 13:47:36</td>
                                                            <td>12/08/2021 13:47:36</td>
                                                            <td></td>
                                                            <td>Betlion-ke Web</td>
                                                            <td>IE</td>
                                                        </tr>
                                                        <tr>
                                                            <td>16351</td>
                                                            <td>03/08/2021 13:47:36</td>
                                                            <td>10/08/2021 13:47:36</td>
                                                            <td></td>
                                                            <td>Betlion-ke Web</td>
                                                            <td>IE</td>
                                                        </tr>
                                                        <tr>
                                                            <td>15581</td>
                                                            <td>28/07/2021 13:47:36</td>
                                                            <td>02/08/2021 13:47:36</td>
                                                            <td></td>
                                                            <td>Betlion-ke Web</td>
                                                            <td>IE</td>
                                                        </tr>
                                                        <tr>
                                                            <td>15501</td>
                                                            <td>28/08/2021 13:47:36</td>
                                                            <td>28/07/2021 13:47:36</td>
                                                            <td></td>
                                                            <td>Betlion-ke Web</td>
                                                            <td>IE</td>
                                                        </tr>
                                                        <tr>
                                                            <td>14581</td>
                                                            <td>28/08/2021 13:47:36</td>
                                                            <td>28/07/2021 13:47:36</td>
                                                            <td></td>
                                                            <td>Betlion-ke Web</td>
                                                            <td>IE</td>
                                                        </tr>
                                                        <tr>
                                                            <td>14551</td>
                                                            <td>28/08/2021 13:47:36</td>
                                                            <td>28/07/2021 13:47:36</td>
                                                            <td></td>
                                                            <td>Betlion-ke Web</td>
                                                            <td>IE</td>
                                                        </tr>
                                                        <tr>
                                                            <td>13571</td>
                                                            <td>28/08/2021 13:47:36</td>
                                                            <td>28/07/2021 13:47:36</td>
                                                            <td></td>
                                                            <td>Betlion-ke Web</td>
                                                            <td>IE</td>
                                                        </tr>





                                                    </tbody>

                                                </table>
                                            </div>

                                            
                     
                     {/* <betHistoryTable tableData = {this.state.data}/>  */}
        </>)
    }
}
function mapStateToProps(state) {
    //console.log("state",state)
    return {
        displayValue: state.sidebar.displayValue,
        sidebarTabs: state.sidebar.sidebarTabs,
    };
}
function mapDispatchToProps(dispatch) {
  return {
      dispatch,
      actions: bindActionCreators({
      }, dispatch)
  }
}
export default connect(mapStateToProps,mapDispatchToProps)(LoginHistory);